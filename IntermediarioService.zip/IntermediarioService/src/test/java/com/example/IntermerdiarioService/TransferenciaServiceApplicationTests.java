package com.example.IntermerdiarioService;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TransferenciaServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
