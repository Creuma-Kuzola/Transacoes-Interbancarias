/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.example.IntermerdiarioService.services.implementacao;

import com.example.IntermerdiarioService.entities.Banco;
import com.example.IntermerdiarioService.services.BancoService;
import org.springframework.stereotype.Service;

/**
 *
 * @author creuma
 */
@Service
public class BancoServiceImpl extends AbstractService<Banco, Integer>
implements BancoService{
    
}
