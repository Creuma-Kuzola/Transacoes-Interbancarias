/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.example.IntermerdiarioService.services.implementacao;

import com.example.IntermerdiarioService.entities.Cliente;
import com.example.IntermerdiarioService.services.ClienteService;
import org.springframework.stereotype.Service;

/**
 *
 * @author creuma
 */
@Service
public class ClienteServiceImpl extends AbstractService<Cliente, Integer>
implements ClienteService {
    
}
