package com.example.IntermerdiarioService.controllers;

import com.example.IntermerdiarioService.https.utils.ResponseControllerUtils;

public class BaseController extends ResponseControllerUtils {

}
