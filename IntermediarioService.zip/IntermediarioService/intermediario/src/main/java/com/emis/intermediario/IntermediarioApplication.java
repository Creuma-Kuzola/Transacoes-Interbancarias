package com.emis.intermediario;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class IntermediarioApplication {

	public static void main(String[] args) {
		SpringApplication.run(IntermediarioApplication.class, args);
	}

}
